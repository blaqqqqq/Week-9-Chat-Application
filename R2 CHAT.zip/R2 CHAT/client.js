const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

const socket = io("http://localhost:3000");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

// Generate RSA Key Pair
const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
  modulusLength: 2048,
});

// Store the registered username
let registeredUsername = "";
let username = "";

// Store users' public keys
const users = new Map();

socket.on("connect", () => {
  console.log("Connected to the server");

  rl.question("Enter your username: ", (input) => {
    username = input;
    registeredUsername = input;

    // Register public key with the server
    socket.emit("registerPublicKey", {
      username,
      publicKey: publicKey.export({ type: "spki", format: "pem" }),
    });

    console.log(`Welcome, ${username} to the chat`);
    rl.prompt();

    rl.on("line", (message) => {
      if (message.trim()) {
        if ((match = message.match(/^!impersonate (\w+)$/))) {
          username = match[1];
          console.log(`Now impersonating as ${username}`);
        } else if (message.match(/^!exit$/)) {
          username = registeredUsername;
          console.log(`Now you are ${username}`);
        } else {
          const signature = signMessage(privateKey, message);
          socket.emit("message", { username, message, signature });
        }
      }
      rl.prompt();
    });
  });
});

// Receive initial user list
socket.on("init", (keys) => {
  keys.forEach(([user, key]) => users.set(user, key));
  console.log(`\nThere are currently ${users.size} users in the chat`);
  rl.prompt();
});

// Handle new user registration
socket.on("newUser", (data) => {
  const { username } = data;
  console.log(`${username} joined the chat`);
  rl.prompt();
});

// Handle incoming messages
socket.on("message", (data) => {
  const { username: senderUsername, message } = data;
  console.log(`${senderUsername}: ${message}`);
  rl.prompt();
});

// Handle warnings
socket.on("warning", (data) => {
  const { username, message } = data;
  console.log(`⚠️ ${message} by ${username}`);
  rl.prompt();
});

// Disconnect handler
socket.on("disconnect", () => {
  console.log("Server disconnected, exiting...");
  rl.close();
  process.exit(0);
});

// Exit on SIGINT
rl.on("SIGINT", () => {
  console.log("\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});

// Sign a message
function signMessage(privateKey, message) {
  const sign = crypto.createSign("SHA256");
  sign.update(message);
  sign.end();
  return sign.sign(privateKey, "hex");
}
