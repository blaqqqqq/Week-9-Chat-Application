const io = require('socket.io-client');
const readline = require('readline');
const crypto = require('crypto');

// Fungsi untuk membuat hash dari pesan
function hashMessage(message) {
  return crypto.createHash('sha256').update(message).digest('hex');
}

// Inisialisasi Socket.IO dan Readline
const socket = io('http://localhost:3000');
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

let username = '';

// Prompt untuk username
socket.on('connect', () => {
  console.log('Terhubung ke server.');

  rl.question('Masukkan username Anda: ', (input) => {
    username = input;
    console.log(`Selamat datang, ${username}! Ketik pesan untuk memulai chat.`);
  });
});

// Mengirim pesan ke server
rl.on('line', (message) => {
  if (message.trim()) {
    const messageHash = hashMessage(message);
    socket.emit('message', { username, message, hash: messageHash });
  }
});

// Mendengarkan pesan dari server
socket.on('message', (data) => {
  const { username: senderUsername, message: senderMessage, hash } = data;

  // Hitung hash pesan yang diterima
  const computedHash = hashMessage(senderMessage.replace(' (sus?)', ''));

  // Periksa apakah hash cocok
  if (computedHash !== hash) {
    console.log(`[Peringatan] Pesan dari ${senderUsername} mungkin telah diubah selama transmisi!`);
  } else {
    console.log(`${senderUsername}: ${senderMessage}`);
  }
});

// Menangani putus koneksi
socket.on('disconnect', () => {
  console.log('Terputus dari server.');
  rl.close();
  process.exit(0);
});

// Menangani keluar aplikasi dengan Ctrl+C
rl.on('SIGINT', () => {
  console.log('\nKeluar dari aplikasi...');
  socket.disconnect();
  rl.close();
  process.exit(0);
});
