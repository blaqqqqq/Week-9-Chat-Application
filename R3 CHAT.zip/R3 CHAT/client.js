const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

const socket = io("http://localhost:3000");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

let targetUsername = "";
let username = "";
const users = new Map();
let privateKey;

// Generate RSA key pair
const { publicKey, privateKey: generatedPrivateKey } = crypto.generateKeyPairSync("rsa", {
  modulusLength: 2048,
});
privateKey = generatedPrivateKey.export({ type: "pkcs1", format: "pem" });

socket.on("connect", () => {
  console.log("Connected to the server");

  rl.question("Enter your username: ", (input) => {
    username = input;
    console.log(`Welcome, ${username} to the chat`);

    // Register the public key with the server
    socket.emit("registerPublicKey", {
      username,
      publicKey: publicKey.export({ type: "pkcs1", format: "pem" }),
    });
    rl.prompt();

    rl.on("line", (message) => {
      if (message.trim()) {
        if ((match = message.match(/^!secret (\w+)$/))) {
          targetUsername = match[1];
          console.log(`Now secretly chatting with ${targetUsername}`);
        } else if (message.match(/^!exit$/)) {
          console.log(`No more secretly chatting with ${targetUsername}`);
          targetUsername = "";
        } else {
          if (targetUsername) {
            const targetPublicKey = users.get(targetUsername);
            if (targetPublicKey) {
              // Encrypt the message for the target user
              const encryptedMessage = crypto
                .publicEncrypt(targetPublicKey, Buffer.from(message))
                .toString("base64");
              socket.emit("message", { username, message: encryptedMessage, target: targetUsername });
            } else {
              console.log(`Public key for ${targetUsername} not found.`);
            }
          } else {
            socket.emit("message", { username, message });
          }
        }
      }
      rl.prompt();
    });
  });
});

socket.on("init", (keys) => {
  keys.forEach(([user, { publicKey }]) => users.set(user, publicKey));
  console.log(`\nThere are currently ${users.size} users in the chat`);
  rl.prompt();
});

socket.on("newUser", (data) => {
  const { username, publicKey } = data;
  users.set(username, publicKey);
  console.log(`${username} joined the chat`);
  rl.prompt();
});

socket.on("message", (data) => {
  const { username: senderUsername, message: senderMessage, encrypted } = data;
  if (senderUsername !== username) {
    if (encrypted) {
      try {
        const decryptedMessage = crypto
          .privateDecrypt(privateKey, Buffer.from(senderMessage, "base64"))
          .toString();
        console.log(`${senderUsername} (encrypted): ${decryptedMessage}`);
      } catch (err) {
        console.log(`${senderUsername} (encrypted): [Could not decrypt message]`);
      }
    } else {
      console.log(`${senderUsername}: ${senderMessage}`);
    }
    rl.prompt();
  }
});

socket.on("disconnect", () => {
  console.log("Server disconnected, Exiting...");
  rl.close();
  process.exit(0);
});

rl.on("SIGINT", () => {
  console.log("\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});
