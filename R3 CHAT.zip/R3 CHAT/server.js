const http = require("http");
const socketIo = require("socket.io");

const server = http.createServer();
const io = socketIo(server);

const users = new Map();

io.on("connection", (socket) => {
  console.log("New client connected");

  socket.on("registerPublicKey", (data) => {
    const { username, publicKey } = data;
    users.set(username, { publicKey, socketId: socket.id });
    console.log(`${username} joined the chat with public key`);
    
    // Send updated user list to all clients
    socket.broadcast.emit("newUser", { username, publicKey });
    socket.emit("init", Array.from(users.entries()));
  });

  socket.on("message", (data) => {
    const { username, message, target } = data;

    if (target) {
      const targetUser = users.get(target);
      if (targetUser) {
        // Send the encrypted message directly to the target user
        io.to(targetUser.socketId).emit("message", {
          username,
          message,
          encrypted: true,
        });
      } else {
        console.log(`User ${target} not found.`);
      }
    } else {
      // Broadcast public messages to everyone
      socket.broadcast.emit("message", { username, message });
    }
  });

  socket.on("disconnect", () => {
    console.log("Client disconnected");
    for (let [username, user] of users) {
      if (user.socketId === socket.id) {
        users.delete(username);
        break;
      }
    }
  });
});

server.listen(3000, () => {
  console.log("Server is running on port 3000");
});
